from qgis.PyQt.QtWidgets import QAction, QDialog
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtCore import QObject
from qgis.utils import iface

from .geometricpro_dialog import GeoMetricDialog

class GeoMetricPro(QObject):
    def __init__(self, iface):
        super().__init__()
        self.iface = iface
        self.action = None
        self.dialog = None

    def initGui(self):
        icon = QIcon()  # Puedes usar QIcon(":/icons/icon.png") si tienes uno
        self.action = QAction(icon, "GeoMetric Pro", self.iface.mainWindow())
        self.action.triggered.connect(self.mostrar_dialogo)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu("&GeoMetric Pro", self.action)

    def unload(self):
        if self.action:
            self.iface.removeToolBarIcon(self.action)
            self.iface.removePluginMenu("&GeoMetric Pro", self.action)

    def mostrar_dialogo(self):
        if not self.dialog:
            self.dialog = GeoMetricDialog(self.iface)
        self.dialog.show()
        self.dialog.raise_()
        self.dialog.activateWindow()
