def classFactory(iface):
    from .geometricpro import GeoMetricPro
    return GeoMetricPro(iface)

