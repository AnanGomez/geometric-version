from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QLabel, QPushButton, QFileDialog,
    QMessageBox, QInputDialog, QProgressDialog
)
from qgis.PyQt.QtCore import Qt, QProcess
from qgis.core import (
    QgsProject,
    QgsGeometry,
    QgsCoordinateReferenceSystem,
    QgsWkbTypes,
    QgsVectorFileWriter,
    QgsVectorLayer,
    QgsFeature,
    QgsDistanceArea
)
import os
import requests
import sys

LICENSE_FILE = os.path.expanduser("~/.geometricpro_license.lic")

class GeoMetricDialog(QDialog):
    VALIDAR_URL = "https://script.google.com/macros/s/AKfycbx_q1eMO6h1ZhDHac_gIhs5l8wuH9zXS5QjXelgesaBST-b3SzFGLWGFGXOkL-wiSWf/exec"

    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.setWindowTitle("GeoMetric Pro By Anan Gomez")
        self.setMinimumWidth(300)
        self.setWindowFlags(self.windowFlags() | Qt.WindowStaysOnTopHint)

        self.layout = QVBoxLayout()
        self.info_label = QLabel("Selecciona un objeto en la capa activa y usa los botones.")
        self.layout.addWidget(self.info_label)

        self.boton_medir = QPushButton("Medir geometría")
        self.boton_medir.clicked.connect(self.medir_geometria)
        self.layout.addWidget(self.boton_medir)

        self.boton_cargar_vector = QPushButton("Cargar SHP o KML")
        self.boton_cargar_vector.clicked.connect(self.cargar_vector)
        self.layout.addWidget(self.boton_cargar_vector)

        self.boton_guardar = QPushButton("Guardar selección como Shapefile")
        self.boton_guardar.clicked.connect(self.guardar_shape)
        self.layout.addWidget(self.boton_guardar)

        self.boton_guardar_kml = QPushButton("Guardar selección como KML (requiere licencia)")
        self.boton_guardar_kml.clicked.connect(self.guardar_kml)
        self.layout.addWidget(self.boton_guardar_kml)

        self.boton_cargar_raster = QPushButton("Cargar raster (requiere licencia)")
        self.boton_cargar_raster.clicked.connect(self.cargar_raster)
        self.layout.addWidget(self.boton_cargar_raster)

        self.boton_crear_overviews = QPushButton("Crear overviews para raster")
        self.boton_crear_overviews.clicked.connect(self.crear_overviews)
        self.layout.addWidget(self.boton_crear_overviews)

        self.boton_unir_geom = QPushButton("Unir geometrías")
        self.boton_unir_geom.clicked.connect(self.unir_geometrias)
        self.layout.addWidget(self.boton_unir_geom)

        self.boton_ingresar_licencia = QPushButton("Ingresar código de licencia")
        self.boton_ingresar_licencia.clicked.connect(self.ingresar_licencia)
        self.layout.addWidget(self.boton_ingresar_licencia)

        self.boton_cargar_archivo_licencia = QPushButton("Cargar archivo de licencia")
        self.boton_cargar_archivo_licencia.clicked.connect(self.cargar_archivo_licencia)
        self.layout.addWidget(self.boton_cargar_archivo_licencia)

        self.setLayout(self.layout)

        self.codigo_licencia = None
        self.licencia_valida = False
        self._leer_licencia_y_validar()

        # Para controlar el proceso gdaladdo
        self.process = None
        self.progress_dialog = None
        # Verificar si hay una nueva versión
        self.verificar_actualizacion()

    VERSION_FILE_URL = "https://raw.githubusercontent.com/AnanGomez/geometric-version/refs/heads/main/version.txt"

    def verificar_actualizacion(self):
        try:
            # Hacer la solicitud GET para obtener el contenido del archivo version.txt
            response = requests.get(self.VERSION_FILE_URL, timeout=10)
            
            if response.status_code == 200:
                version_actual = "1.0.0"  # Esta es la versión de tu aplicación actual
                version_nueva = response.text.strip()  # Obtenemos la versión del archivo `version.txt`
                
                # Comparar versiones
                if self.comparar_versiones(version_actual, version_nueva):
                    QMessageBox.information(
                        self,
                        "GeoMetric Pro",
                        f"¡Nueva actualización disponible! La versión {version_nueva} está disponible. "
                        "Por favor, actualiza tu aplicación para obtener las últimas características y mejoras."
                    )
                else:
                    self.info_label.setText("Estás usando la versión más reciente.")
            else:
                self.info_label.setText("No se pudo verificar la actualización.")
        except requests.RequestException as e:
            self.info_label.setText(f"Error al verificar actualización: {e}")

    def comparar_versiones(self, version_actual, version_nueva):
        # Comparar las versiones
        version_actual_parts = list(map(int, version_actual.split(".")))
        version_nueva_parts = list(map(int, version_nueva.split(".")))
        
        return version_nueva_parts > version_actual_parts

    def crear_overviews(self):
        if not self.licencia_valida:
            QMessageBox.warning(self, "GeoMetric Pro", "Función restringida. Ingresa una licencia válida.")
            return

        ruta, _ = QFileDialog.getOpenFileName(
            self,
            "Seleccionar raster para generar overviews",
            "",
            "Raster (*.tif *.tiff)"
        )
        if not ruta:
            return

        self.progress_dialog = QProgressDialog("Creando overviews...", "Cancelar", 0, 100, self)
        self.progress_dialog.setWindowModality(Qt.WindowModal)
        self.progress_dialog.setMinimumDuration(0)
        self.progress_dialog.setValue(0)
        self.progress_dialog.show()

        # Construimos los argumentos para gdaladdo
        args = [
            "gdaladdo",
            "-r", "gauss",
            "--config", "COMPRESS_OVERVIEW", "LZW",
            "--config", "INTERLEAVE_OVERVIEW", "PIXEL",
            "--config", "GDAL_TIFF_INTERNAL_MASK", "YES",
            ruta,
            "8"
        ]

        # Usamos QProcess para ejecutar sin ventana consola y para captar la salida
        self.process = QProcess(self)
        # En Windows para evitar consola negra (Qt 5+)
        self.process.setProcessChannelMode(QProcess.MergedChannels)

        # Conectamos señales para procesar salida y fin
        self.process.readyReadStandardOutput.connect(self._procesar_salida_overviews)
        self.process.finished.connect(self._finalizar_overviews)

        try:
            self.process.start(args[0], args[1:])
        except Exception as e:
            QMessageBox.critical(self, "GeoMetric Pro", f"Error al iniciar gdaladdo:\n{e}")
            self.progress_dialog.cancel()
            self.process = None

    def _procesar_salida_overviews(self):
        if self.process is None:
            return
        salida = self.process.readAllStandardOutput().data().decode()
        # Aquí puedes parsear la salida para obtener el progreso si gdaladdo lo reporta (no lo hace por defecto).
        # Así que para este caso, solo simulamos progreso incrementando o mostrar mensaje.
        # Como alternativa, podrías mostrar mensajes en info_label:
        self.info_label.setText("Procesando overviews...")

        # Si quieres mostrar algo en la barra de progreso, puedes simularlo:
        val_actual = self.progress_dialog.value()
        if val_actual < 100:
            self.progress_dialog.setValue(val_actual + 10)

    def _finalizar_overviews(self, exitCode, exitStatus):
        if self.progress_dialog:
            self.progress_dialog.setValue(100)
            self.progress_dialog.close()
            self.progress_dialog = None

        if exitCode == 0:
            QMessageBox.information(self, "GeoMetric Pro", "Overviews creados correctamente.")
            self.info_label.setText("Overviews creados correctamente.")
        else:
            salida_error = self.process.readAllStandardOutput().data().decode() if self.process else ""
            QMessageBox.warning(self, "GeoMetric Pro", f"Error creando overviews:\n{salida_error}")
            self.info_label.setText("Error al crear overviews.")

        self.process = None

    def showEvent(self, event):
        super().showEvent(event)
        self.raise_()
        self.activateWindow()

    def _leer_licencia_y_validar(self):
        if os.path.exists(LICENSE_FILE):
            try:
                with open(LICENSE_FILE, "r") as f:
                    self.codigo_licencia = f.read().strip()
            except Exception as e:
                self.info_label.setText(f"Error leyendo licencia: {e}")
                self.licencia_valida = False
                return
            self.licencia_valida = self.validar_licencia(self.codigo_licencia)
            if self.licencia_valida:
                self.info_label.setText("Licencia válida. Todas las funciones habilitadas.")
            else:
                self.info_label.setText("Licencia inválida. Algunas funciones están deshabilitadas.")
        else:
            self.info_label.setText("No se encontró licencia. Algunas funciones están deshabilitadas.")
            self.licencia_valida = False
        self._actualizar_estado_botones()

    def validar_licencia(self, codigo_licencia):
        if not codigo_licencia:
            return False
        try:
            response = requests.get(self.VALIDAR_URL, params={"codigo": codigo_licencia}, timeout=10)
            if response.status_code == 200:
                data = response.json()
                return data.get("estado", "invalido") == "valido"
            else:
                return False
        except Exception as e:
            print(f"Error al validar licencia: {e}")
            return False

    def ingresar_licencia(self):
        codigo, ok = QInputDialog.getText(self, "Ingresar licencia", "Introduce tu código de licencia:")
        if ok and codigo:
            codigo = codigo.strip()
            if self.validar_licencia(codigo):
                try:
                    with open(LICENSE_FILE, "w") as f:
                        f.write(codigo)
                    self.codigo_licencia = codigo
                    self.licencia_valida = True
                    QMessageBox.information(self, "GeoMetric Pro", "Licencia válida guardada. Funciones habilitadas.")
                    self.info_label.setText("Licencia válida. Todas las funciones habilitadas.")
                    self._actualizar_estado_botones()
                except Exception as e:
                    QMessageBox.warning(self, "GeoMetric Pro", f"No se pudo guardar la licencia: {e}")
            else:
                QMessageBox.warning(self, "GeoMetric Pro", "Código de licencia inválido.")

    def cargar_archivo_licencia(self):
        ruta_licencia, _ = QFileDialog.getOpenFileName(
            self,
            "Seleccionar archivo de licencia",
            "",
            "Archivos licencia (*.lic)"
        )
        if not ruta_licencia:
            return
        try:
            with open(ruta_licencia, "r") as f:
                contenido = f.read().strip()
            if self.validar_licencia(contenido):
                with open(LICENSE_FILE, "w") as f:
                    f.write(contenido)
                self.codigo_licencia = contenido
                self.licencia_valida = True
                QMessageBox.information(self, "GeoMetric Pro", "Licencia cargada y validada correctamente.")
                self.info_label.setText("Licencia válida. Todas las funciones habilitadas.")
                self._actualizar_estado_botones()
            else:
                QMessageBox.warning(self, "GeoMetric Pro", "Licencia cargada, pero inválida.")
        except Exception as e:
            QMessageBox.warning(self, "GeoMetric Pro", f"No se pudo cargar la licencia: {e}")

    def _actualizar_estado_botones(self):
        self.boton_guardar_kml.setEnabled(self.licencia_valida)
        self.boton_cargar_raster.setEnabled(self.licencia_valida)

    def medir_geometria(self):
        layer = self.iface.activeLayer()
        if not layer:
            self.info_label.setText("No hay capa activa.")
            return

        seleccion = layer.selectedFeatures()
        if not seleccion:
            self.info_label.setText("No hay geometría seleccionada.")
            return

        geom = QgsGeometry(seleccion[0].geometry())
        tipo = geom.type()

        d = QgsDistanceArea()
        d.setSourceCrs(layer.crs(), QgsProject.instance().transformContext())
        d.setEllipsoid(QgsProject.instance().ellipsoid())

        try:
            if tipo == QgsWkbTypes.PolygonGeometry:
                area_m2 = d.measureArea(geom)
                area_ha = area_m2 / 10000
                self.info_label.setText(f"Área: {area_m2:.2f} m² ≈ {area_ha:.2f} ha")
            elif tipo == QgsWkbTypes.LineGeometry:
                longitud_m = d.measureLength(geom)
                self.info_label.setText(f"Longitud: {longitud_m:.2f} m")
            else:
                self.info_label.setText("Es un punto, no tiene área ni longitud.")
        except Exception as e:
            self.info_label.setText(f"Error al medir geometría: {e}")


    def cargar_vector(self):
        ruta, _ = QFileDialog.getOpenFileName(
            self,
            "Seleccionar archivo vectorial",
            "",
            "Archivos vectoriales (*.shp *.kml)"
        )
        if not ruta:
            return

        if ruta.lower().endswith(".shp") or ruta.lower().endswith(".kml"):
            layer = QgsVectorLayer(ruta, os.path.basename(ruta), "ogr")
        else:
            QMessageBox.warning(self, "GeoMetric Pro", "Formato no soportado.")
            return

        if not layer.isValid():
            QMessageBox.warning(self, "GeoMetric Pro", "No se pudo cargar la capa.")
            return

        QgsProject.instance().addMapLayer(layer)
        self.info_label.setText(f"Capa cargada: {os.path.basename(ruta)}")

    def guardar_shape(self):
        layer = self.iface.activeLayer()
        if not layer:
            self.info_label.setText("No hay capa activa.")
            return

        seleccion = layer.selectedFeatures()
        if not seleccion:
            self.info_label.setText("No hay selección.")
            return

        ruta_guardar, _ = QFileDialog.getSaveFileName(
            self,
            "Guardar selección como shapefile",
            "",
            "Shapefile (*.shp)"
        )
        if not ruta_guardar:
            return

        # Crear una nueva capa para guardar la selección
        error = QgsVectorFileWriter.writeAsVectorFormat(
            layer,
            ruta_guardar,
            "UTF-8",
            layer.crs(),
            "ESRI Shapefile",
            onlySelected=True
        )
        if error == QgsVectorFileWriter.NoError:
            QMessageBox.information(self, "GeoMetric Pro", "Archivo guardado correctamente.")
       	else:
           	    QMessageBox.information(self, "GeoMetric Pro", "Archivo guardado correctamente.")

    def guardar_kml(self):
        if not self.licencia_valida:
            QMessageBox.warning(self, "GeoMetric Pro", "Función restringida. Ingresa una licencia válida.")
            return

        layer = self.iface.activeLayer()
        if not layer:
            self.info_label.setText("No hay capa activa.")
            return

        seleccion = layer.selectedFeatures()
        if not seleccion:
            self.info_label.setText("No hay selección.")
            return

        ruta_guardar, _ = QFileDialog.getSaveFileName(
            self,
            "Guardar selección como KML",
            "",
            "KML (*.kml)"
        )
        if not ruta_guardar:
            return

        # Verificar que no se intenten guardar múltiples geometrías (puedes adaptar la lógica)
        if len(seleccion) > 1:
            QMessageBox.warning(self, "GeoMetric Pro", "Advertencia: Se guardarán múltiples geometrías en un solo archivo KML.")
        
        error = QgsVectorFileWriter.writeAsVectorFormat(
            layer,
            ruta_guardar,
            "UTF-8",
            layer.crs(),
            "KML",
            onlySelected=True
        )
        if error == QgsVectorFileWriter.NoError:
            QMessageBox.information(self, "GeoMetric Pro", "Archivo KML guardado correctamente.")
        else:
            QMessageBox.information(self, "GeoMetric Pro", "Archivo KML guardado correctamente.")

    def cargar_raster(self):
        if not self.licencia_valida:
            QMessageBox.warning(self, "GeoMetric Pro", "Función restringida. Ingresa una licencia válida.")
            return

        ruta, _ = QFileDialog.getOpenFileName(
            self,
            "Seleccionar archivo raster",
            "",
            "Raster (*.tif *.tiff)"
        )
        if not ruta:
            return

        from qgis.core import QgsRasterLayer
        layer = QgsRasterLayer(ruta, os.path.basename(ruta))
        if not layer.isValid():
            QMessageBox.warning(self, "GeoMetric Pro", "No se pudo cargar el raster.")
            return

        QgsProject.instance().addMapLayer(layer)
        self.info_label.setText(f"Raster cargado: {os.path.basename(ruta)}")

    def unir_geometrias(self):
        layer = self.iface.activeLayer()
        if not layer:
            self.info_label.setText("No hay capa activa.")
            return

        seleccion = layer.selectedFeatures()
        if len(seleccion) < 2:
            self.info_label.setText("Selecciona al menos dos geometrías para unir.")
            return

        from shapely.ops import unary_union
        from shapely.geometry import shape
        try:
            geoms = [shape(f.geometry().asJson()) for f in seleccion]
            union_geom = unary_union(geoms)
        except Exception as e:
            self.info_label.setText(f"Error al unir geometrías: {e}")
            return

        # Crear una nueva capa temporal para mostrar la unión
        uri = "Polygon?crs={}".format(layer.crs().authid())
        capa_union = QgsVectorLayer(uri, "Unión Geometrías", "memory")
        prov = capa_union.dataProvider()

        nueva_feat = QgsFeature()
        nueva_feat.setGeometry(QgsGeometry.fromWkt(union_geom.wkt))
        prov.addFeatures([nueva_feat])
        capa_union.updateExtents()

        QgsProject.instance().addMapLayer(capa_union)
        self.info_label.setText("Geometrías unidas y agregadas como nueva capa.")

